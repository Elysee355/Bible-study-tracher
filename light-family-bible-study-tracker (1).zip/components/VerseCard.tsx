
import React from 'react';
import { VerseOfTheDay } from '../types';

interface VerseCardProps {
  verse: VerseOfTheDay | null;
  loading: boolean;
}

const VerseCard: React.FC<VerseCardProps> = ({ verse, loading }) => {
  if (loading) return <div className="w-full bg-white rounded-3xl p-8 text-center animate-pulse border border-yellow-100 shadow-xl"><div className="h-4 bg-gray-200 rounded w-3/4 mx-auto mb-4"></div></div>;
  if (!verse) return null;
  return (
    <div className="relative overflow-hidden w-full bg-white rounded-3xl p-8 md:p-12 text-center border-2 border-yellow-100 shadow-2xl glow-gold">
      <div className="max-w-3xl mx-auto">
        <h3 className="text-sm font-bold text-gray-400 uppercase tracking-[0.2em] mb-6">Verse of the Day</h3>
        <blockquote className="text-2xl md:text-3xl font-serif text-[#2D3748] mb-4 italic leading-tight">"{verse.verse}"</blockquote>
        <cite className="block text-lg font-bold text-[#D4AF37] not-italic mb-8">— {verse.reference}</cite>
        <div className="relative pt-6 border-t border-yellow-100">
          <p className="text-gray-500 font-medium max-w-xl mx-auto italic">{verse.reflection}</p>
        </div>
      </div>
    </div>
  );
};

export default VerseCard;
